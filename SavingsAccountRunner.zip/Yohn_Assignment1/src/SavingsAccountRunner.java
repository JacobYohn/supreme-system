/** Program header:  SavingsAccountRunner.java
 *
 * Author:    Jacob Yohn
 * Class:     Java
 *
 * Brief Program Description:
 *   Asks the User to input account number, initial balance, and annual interest rate.
 *   Calculates weekly interest, deposits to total balance and displays account details.
 */
import java.util.Scanner;
public class SavingsAccountRunner {
	public static void main (String[] args)
	{
		Scanner input = new Scanner(System.in);
		
		//Welcome user
		System.out.println("Welcome to your Savings Account App!");
		
		//get user account number
		int account_number = 0;
		System.out.print("Enter account number: ");
		account_number = input.nextInt();
		
		//get user initial balance
		double initial_balance = 0.0;
		System.out.print("Enter initial balance: ");
		initial_balance = input.nextDouble();
		
		//get annual interest rate
		double annual_interestRate = 0.0;
		System.out.print("Enter annual interest rate: ");
		annual_interestRate = input.nextDouble();
		
		//set account
		Account account = new Account(account_number, initial_balance);
		
		//set annual interest rate
		account.setInterestRate(annual_interestRate);
		
		//create input variable
		int userchoice = 0;
		
		//set do loop
	do {
		
		//spacing
		System.out.println(" ");

		//display options
		System.out.println("=============================");
		System.out.println("=       OPTIONS BELOW       =");
		System.out.println("=============================");
		System.out.println(" ");
		System.out.println("1. Deposit");
		System.out.println("2. View Weekly Interest Rate");
		System.out.println("3. View Account Details");
		System.out.println("4. Exit");
		System.out.print("Enter your selection: ");
		userchoice = input.nextInt();
		
		//check for errors
		while (userchoice != 1 && userchoice != 2 && userchoice != 3 && userchoice != 4)
		{
			System.out.print("INVALID SELECTION - TRY AGAIN! ");
			userchoice = input.nextInt();
		}
		
		//run switch for options
			switch (userchoice)
			{
				case (1):
				{
					double depositamount;
					System.out.print("Enter your deposit amount: ");
					depositamount = input.nextDouble();
					
					//check for deposit error
						while(depositamount < 0)
						{
							System.out.print("Error! Deposit amount must be greater than 0! Try again! ");
							depositamount = input.nextDouble();
						}
					
					//Add deposit to total balance and display new total
					account.deposit_amount(depositamount);
					System.out.println("New Balance: " + account.access_balance());
					break;
				}
				case (2):
				{
					System.out.printf("Your weekly interest amount is $" + "%.2f", account.getWeeklyInterest());
					
					//spacing
					System.out.println(" ");
					
					break;
				}
				case (3):
				{
					System.out.println("Account ID: " + account.access_id());
					System.out.println("Account Creation Date/Time: " + account.getDateEstablished());
					System.out.println("Balance: " + account.access_balance());
					System.out.printf("Weekly interest amount: $" + "%.2f", account.getWeeklyInterest());
					
					//spacing
					System.out.println(" ");
					
					break;
				}
				case (4):
				{
					System.out.println("Thank you - Goodbye!");
					break;
				}
				
			}
	 }while(userchoice != 4);
		
	}
}
	class Account{
		//create data field id for account
		private int id = 0;
		//create account balance data field
		private double balance = 0.0;
		//create current interest rate data field
		private double annualIntRate = 0.0;
		//create data field to store the date
		private java.util.Date dateEstablished;
		
		//create default account constructor
		public Account()
		{
			dateEstablished = new java.util.Date();
		}
		
		//create constructor for account with specified id and balance
		public Account(int specified_id, double specified_balance)
		{
			this();
			id = specified_id;
			balance = specified_balance;
		}
		
		//create id accessor 
		public int access_id()
		{
			return id;
		}
		
		//create id mutator
		public void setid(int set_id)
		{
			id = set_id;
		}
		
		//create balance accessor
		public double access_balance()
		{
			return balance;
		}
		
		//create balance mutator
		public void setbalance(double set_balance)
		{
			balance = set_balance;
		}
		
		//create annual interest rate accessor
		public double access_interestRate()
		{
			return annualIntRate;
		}
		
		//create annual interest rate mutator
		public void setInterestRate(double set_annualIntRate)
		{
			annualIntRate = set_annualIntRate;
		}
		
		//accessor method for date established
		public String getDateEstablished()
		{
			return this.dateEstablished.toString();
		}
		
		//create get weekly interest rate method
		public double getWeeklyInterestRate()
		{
			return ((annualIntRate / 100) / 52);
		}
		
		//get weekly interest
		public double getWeeklyInterest()
		{
			return (balance * getWeeklyInterestRate());
		}
		
		//create deposit method
		public void deposit_amount(double amount)
		{
			this.balance += amount;
		}
	  }
